clear
clc

target = 'nurul';

besar_populasi = 3;
populasi = create_population(target,besar_populasi);